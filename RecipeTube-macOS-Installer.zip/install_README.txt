Installer scripts

Windows:
- install_windows.bat
  Downloads and runs the RecipeTube Windows installer silently.

macOS:
- install_mac.command
  Downloads RecipeTube.dmg and opens it (then you drag the app into Applications).

Note:
- .bat files do NOT run on macOS/Linux.
- For macOS you distribute the .dmg (the script just helps automate downloading/opening it).
