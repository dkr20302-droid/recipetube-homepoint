Installer scripts

Windows:
- install_windows.bat
  Downloads and runs the RecipeTube Windows installer silently.
  It reads the downloads server URL from base_url.txt (same folder).

macOS:
- install_mac.command
  Downloads RecipeTube.dmg and opens it (then you drag the app into Applications).
  It reads the downloads server URL from base_url.txt (same folder).

Note:
- .bat files do NOT run on macOS/Linux.
- For macOS you distribute the .dmg (the script just helps automate downloading/opening it).
